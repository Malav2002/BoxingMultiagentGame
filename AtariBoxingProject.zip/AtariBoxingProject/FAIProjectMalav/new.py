from training.train import train_agents

if __name__ == "__main__":
    train_agents()
